# Project 5 — Router-on-a-stick
An access port carries one data VLAN. A trunk carries multiple VLANs over one cable. Here switch G0/1 connects to router G0/0, carrying VLANs 10 and 20 using 802.1Q tags.

The router uses virtual interfaces G0/0.10 and G0/0.20. The encapsulation commands associate them with VLAN 10 and VLAN 20. Their IP addresses are the PCs' gateways. The parent physical interface has no IP address and must be enabled.

Traffic from Sales to HR reaches the Sales gateway, is routed to the HR subinterface, and returns over the same physical cable with the HR VLAN tag. VLANs still have separate broadcast domains. Routing enables communication between them; VLAN tagging does not encrypt data.

C means directly connected network; L means the router's own address. No static route is needed between these two connected networks. No default route is needed for this local lab.

## Actual troubleshooting
The learner initially entered switchport mode trunk on a router interface. It was rejected because this configuration belongs on the switch's Ethernet port. The command was then entered on S1-OFFICE G0/1.

Sales-to-HR ping failed, while the router could ping both endpoint PCs. HR-PC1's default gateway was corrected to 192.168.20.1, and the learner confirmed that this fixed the problem. The original incorrect gateway value was not supplied. A local router ping can succeed even with a bad PC gateway, because the router normally sources it from its interface in that PC's subnet. A reply to a PC in a different subnet needs the correct gateway.

## Discussion exercise
If physical router interface G0/0 is shut down, both subinterfaces lose connectivity. Same-VLAN PC communication can still work through the switch. This fault was discussed, not applied to the final project.

## Verification scope
Successful PC-to-PC tests cover SALES-PC1 and HR-PC1 in both directions. Addresses and gateway settings for the other two PCs are the lesson plan; separate Project 5 ping evidence for those PCs was not supplied. The provided .pkt was not independently executed.

## Preservation
The switch running-config does not show VLAN creation/name commands. The build reference includes them so the lab can be reconstructed. Both supplied running configurations have no enable secret configured. No SSH, ACL, NAT or internet connectivity was demonstrated.
