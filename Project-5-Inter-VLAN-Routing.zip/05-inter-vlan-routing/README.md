# Project 5 — Inter-VLAN Routing
This lab extends Project 4 by adding a Cisco 2911 router to route between Sales VLAN 10 and HR VLAN 20 through one trunk link.

## Open and review
Open topology/Project-5-Inter-VLAN-Routing.pkt in Cisco Packet Tracer. View screenshots/Project-5-Network-Evidence.jpg for the combined evidence. Text files contain the configurations and results; addressing/ contains the IP and port plan; documentation/ explains the design and troubleshooting.

## Results
- Sales-to-HR and HR-to-Sales pings: 4/4 replies, 0% loss.
- Router could reach both tested PCs: 5/5 replies each.
- Both subinterfaces showed up/up.
- Trunk output confirmed VLANs 10 and 20 allowed, active and forwarding.
- Routing table contained connected and local routes for both VLANs.
- HR-PC1's default gateway problem was corrected.

## Source and evidence notes
The uploaded files were named "pro 4.png" and "Project 4 Separate departments using VLANs(1).pkt". The screenshot shows the router added for Project 5. The .pkt is included under a Project 5 filename, with bytes unchanged; its internal configuration was not independently inspected or run. Original screenshot bytes are preserved. Command panels are recreated from supplied text, not screenshots. Running-config transcriptions preserve all configuration statements but omit repeated empty separator lines. Verification excerpts identify omitted formatting/columns. Build commands are reference instructions, not a claimed raw transcript.
